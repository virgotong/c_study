这里放置 
https://github.com/lionsoul2016/ip2region/tree/master/binding/c

ip2region.c and ip2region.h
